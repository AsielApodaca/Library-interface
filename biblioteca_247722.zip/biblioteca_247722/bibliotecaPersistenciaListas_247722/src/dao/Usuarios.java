package dao;
import java.util.ArrayList;
import java.util.List;
import objetosNegocio.*;
import excepciones.*;
/**
 * Clase Usuarios
 * @author Asiel Apodaca Monge 00000247722
 */
public class Usuarios {
    private ArrayList<Usuario> usuarios;
    /**
     * Crea la lista usuarios como una instancia del tipo
     * ArrayList<Usuario> para almacenar los usuarios de la biblioteca
     */
    public Usuarios(){
        usuarios = new ArrayList<Usuario>();
    }
    /**
     * Obtiene el usuario de la lista usuarios
     * cuyo número de credencial coincida con el número de credencial del usuario dado por el
     * parámetro, null en caso de no existir.
     * @param usuario
     * @return 
     */
    public Usuario obten(Usuario usuario){
        Usuario user = null;
        for(Usuario usr:usuarios){
            if(usr.getNumCredencial().equals(usuario.getNumCredencial())){
                user = usr;
                break;
            }
                
        }
        return user;
    }
    /**
     * Agrega el usuario dado por el
     * parámetro a la lista usuarios. Este método no restringe número de credenciales
     * repetidas.
     * @param usuario 
     */
    public void agrega(Usuario usuario){
        usuarios.add(usuario);
    }
    /**
     * Reemplaza el usuario de la lista
     * usuarios, cuyo número de credencial coincide con el número de credencial del
     * usuario dado por el parámetro, por el usuario del parámetro. Si el usuario no existe,
     * el método lanza una excepción del tipo DAOException.
     * @param usuario
     * @throws DAOException 
     */
    public void actualiza(Usuario usuario) throws DAOException{
        boolean existe = false;
        for(Usuario usr:usuarios){
            if(usr.getNumCredencial().equals(usuario.getNumCredencial())){
                existe = true;
                usuarios.set(usuarios.indexOf(usr), usuario);
                break;
            }
        }
        if(existe == false)throw new DAOException("Usuario inexistente.");
    }
    /**
     * Elimina el usuario dado por el parámetro,
     * si existe, de la lista usuarios si sus números de credencial coinciden. Si el usuario no
     * existe, el método lanza una excepción del tipo DAOException.
     * @param usuario
     * @throws DAOException 
     */
    public void elimina(Usuario usuario) throws DAOException{
        if(!usuarios.remove(usuario))
        throw  new DAOException("Usuario inexistente.");
    }
    /**
     * Regresa la lista de todos los usuarios
     * @return List usuarios
     */
    public List<Usuario> lista(){
        return usuarios;
    }
    
}
