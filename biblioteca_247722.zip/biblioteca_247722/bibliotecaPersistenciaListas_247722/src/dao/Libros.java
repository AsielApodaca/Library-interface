package dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import objetosNegocio.*;
import excepciones.*;
/**
 * Clase Libros
 * @author Asiel Apodaca Monge 00000247722
 */
public class Libros {
    private ArrayList<Libro> libros;
    /**
     * Crea la lista libros como una instancia del tipo ArrayList<Libro>
     */
    public Libros(){
        libros = new ArrayList<Libro>();
    }
    /**
     * Regresa el libro de la lista
     * libros cuyo ISBN coincide con el ISBN del libro dado por el parámetro, null si no se
     * encuentra.
     * @param publicacion
     * @return Retorna Libro
     * @throws PersistenciaException 
     */
    public Libro obten(Libro publicacion) throws PersistenciaException{
        Libro lbr = null;
        for(Libro l:libros){
            if(l.getIsbn().equals(publicacion.getIsbn())){
                lbr = l;
                break;
            }
        }
        return lbr;
    }
    /**
     * Agrega el libro dado por el
     * parámetro a la lista libros. Este método no restringe ISBN repetidos.
     * @param publicacion
     * @throws DAOException 
     */
    public void agrega(Libro publicacion) throws DAOException{
        libros.add(publicacion);
    }
    /**
     * Reemplaza el libro de la lista
     * libros, cuyo ISBN coincide con el ISBN del libro dado por el parámetro, por el libro
     * del parámetro. Si el libro no existe, el método lanza una excepción del tipo
     * DAOException
     * @param publicacion
     * @throws DAOException 
     */
    public void actualiza(Libro publicacion) throws DAOException{
        boolean existe = false;
        for(Libro libro:libros){
            if(libro.getIsbn().equals(publicacion.getIsbn())){
                existe = true;
                libros.set(libros.indexOf(libro), publicacion);
                break;
            }
        }
        if(existe == false)throw new DAOException("Libro inexistente.");
    }
    /**
     * Elimina el libro dado por el
     * parámetro, si existe, de la lista libros si sus ISBN coinciden. Si el libro no existe, el
     * método lanza una excepción del tipo DAOException
     * @param publicacion
     * @throws DAOException 
     */
    public void elimina(Libro publicacion) throws DAOException{
        int index = libros.indexOf(publicacion);
        if(index<0) throw new DAOException("Libro inexistente.");
        libros.remove(index);
    }
    /**
     * Regresan listas de todos los libros.
     * @return List libros
     */
    public List<Libro> lista(){
        return libros;
    }
    /**
     * Regresan listas de todos los libros con la misma casa editorial.
     * @param editorial
     * @return List libros
     */
    public List<Libro> listaEditorial(String editorial){
        List<Libro> listaEditorial = new ArrayList<Libro>();
        for(Iterator<Libro> iterador = libros.iterator(); iterador.hasNext();){
            Libro libro = iterador.next();
            if(libro.getEditorial().equals(editorial))
                listaEditorial.add(libro);
        }
        return listaEditorial;
    }
    /**
     * Regresan listas de todos los libros con  la misma clasificación.
     * @param clasificacion
     * @return List libros
     */
    public List<Libro> listaClasificacion(String clasificacion){
        List<Libro> listaClasificacion = new ArrayList<Libro>();
        for(Iterator<Libro> iterador = libros.iterator(); iterador.hasNext();){
            Libro libro = iterador.next();
            if(libro.getClasificacion().equals(clasificacion))
                listaClasificacion.add(libro);
        }
        return listaClasificacion;
    }
    /**
     * Regresan listas de todos los libros del mismo autor.
     * @param autor
     * @return List libros
     */
    public List<Libro> listaAutor(String autor){
        List<Libro> listaAutor = new ArrayList<Libro>();
        for(Iterator<Libro> iterador = libros.iterator(); iterador.hasNext();){
            Libro libro = iterador.next();
            if(libro.getAutor().equals(autor))
                listaAutor.add(libro);
        }
        return listaAutor;
    }
}
