package dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import objetosNegocio.*;
import excepciones.*;
/**
 * Clase PublicacionesED
 * @author Asiel Apodaca Monge 00000247722
 */
public class PublicacionesED {
    private ArrayList<PublicacionED> publicacionesED;
    /**
     * Crea la lista publicacionesED como una
     * instancia del tipo ArrayList<PublicacionED> para almacenar el inventario de
     * libros de la biblioteca
     */
    public PublicacionesED(){
        publicacionesED = new ArrayList<PublicacionED>();
    }
    /**
     * Regresa la publicacionED de la lista publicacionesED cuyo ISBN coincide con el ISBN
     * de la publicacionED dada por el parámetro, null si no se encuentra
     * @param publicacionED
     * @return 
     */
    public PublicacionED obten(PublicacionED publicacionED){
        PublicacionED ED = null;
        for(PublicacionED pubED:publicacionesED){
            if(pubED.getPublicacion().getIsbn().equals(publicacionED.getPublicacion().getIsbn())){
                ED = pubED;
                break;
            }
        }
        return ED;
    }
    /**
     * Agrega la publicacionED dada por el parámetro a la lista. Este método no restringe ISBN repetidos.
     * @param publicacionED 
     */
    public void agrega(PublicacionED publicacionED){
        publicacionesED.add(publicacionED);
    }
    /**
     * Reemplaza la
     * publicaciónED de la lista publicacionesED, cuyo ISBN coincide con el ISBN de la
     * publicaciónED dado por el parámetro, por la publicaciónED del parámetro. Si la
     * publicacionED no existe, el método lanza una excepción del tipo DAOException.
     * @param publicacionED
     * @throws DAOException 
     */
    public void actualiza(PublicacionED publicacionED) throws DAOException{
        boolean existe = false;
        for(PublicacionED pubED:publicacionesED){
            if(pubED.getPublicacion().getIsbn().equals(publicacionED.getPublicacion().getIsbn())){
                existe = true;
                publicacionesED.set(publicacionesED.indexOf(pubED), publicacionED);
                break;
            }
        }
        if(existe == false)throw new DAOException("PublicacionED inexistente.");
    }
    /**
     * Elimina la
     * publicacionED de la lista publicacionesED cuyo ISBN coincida con el ISBN de
     * la publicacionED dada por el parámetro. Si la publicacionED no existe, el método
     * lanza una excepción del tipo DAOException.
     * @param publicacionED
     * @throws DAOException 
     */
    public void elimina(PublicacionED publicacionED) throws DAOException{
        int index = publicacionesED.indexOf(publicacionED);
        if(index<0) throw new DAOException("PublicacionED inexistente.");
        publicacionesED.remove(index);
    }
    /**
     * Regresan listas de todas las publicacionesED.
     * @return List publicacionesED
     */
    public List<PublicacionED> lista(){
        return publicacionesED;
    }
    /**
     * Regresan listas de todas las publicacionesED prestadas.
     * @return List publicacionesED
     */
    public List<PublicacionED> listaPrestada(){
        List<PublicacionED> listaPrestada = new ArrayList<PublicacionED>();
        for(Iterator<PublicacionED> iterador = publicacionesED.iterator(); iterador.hasNext();){
            PublicacionED publicacionED = iterador.next();
            if(publicacionED.getDisponibilidad()<publicacionED.getExistencia()){
                listaPrestada.add(publicacionED);
            }
        }
        return listaPrestada;
    }
    /**
     * Regresan listas de todas las publicacionesED disponibles.
     * @return List publicacionesED
     */
    public List<PublicacionED> listaDisponibles(){
        List<PublicacionED> listaDisponibles = new ArrayList<PublicacionED>();
        for(Iterator<PublicacionED> iterador = publicacionesED.iterator(); iterador.hasNext();){
            PublicacionED publicacionED = iterador.next();
            if(publicacionED.getDisponibilidad()>0){
                listaDisponibles.add(publicacionED);
            }
        }
        return listaDisponibles;
    }
}
