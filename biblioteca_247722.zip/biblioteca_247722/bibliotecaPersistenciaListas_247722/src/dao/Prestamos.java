package dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import objetosServicio.*;
import objetosNegocio.*;
import excepciones.*;
/**
 * Clase Prestamos
 * @author Asiel Apodaca Monge 00000247722
 */
public class Prestamos {
    private ArrayList<Prestamo> prestamos;
    /**
     * Crea la lista prestamos como una instancia del tipo
     * ArrayList<Prestamo> para almacenar los préstamos de libros de la biblioteca. 
     */
    public Prestamos(){
        prestamos = new ArrayList<Prestamo>();
    }
    /**
     * Regresa el préstamo de la
     * lista prestamos cuyo ISBN y número de credencial coinciden con el ISBN y
     * número de credencial del préstamo dado por el parámetro, null si no se encuentra.
     * @param prestamo
     * @return Retorna Prestamo
     */
    public Prestamo obten(Prestamo prestamo){
        Prestamo prs = null;
        for(Prestamo p:prestamos){
            if(p.getPublicacion().getIsbn().equals(prestamo.getPublicacion().getIsbn())
                    && p.getUsuario().getNumCredencial().equals(prestamo.getUsuario().getNumCredencial())){
                prs = p;
                break;
            }
        }
        return prs;
    }
    /**
     * Agrega el préstamo dado por el
     * parámetro a la lista prestamos. Este método no restringe a ISBN y números de
     * credencial repetidos.
     * @param prestamo 
     */
    public void agrega(Prestamo prestamo){
        prestamos.add(prestamo);
    }
    /**
     * : Reemplaza el préstamo de la
     * lista prestamos, cuyo ISBN y numCredencial coinciden con el ISBN y número de
     * credencial del préstamo dado por el parámetro, por el préstamo del parámetro. Si el
     * préstamo no existe, el método lanza una excepción del tipo DAOException
     * @param prestamo
     * @throws DAOException 
     */
    public void actualiza(Prestamo prestamo) throws DAOException{
        boolean existe = false;
        for(Prestamo prest:prestamos){
            if(prest.getUsuario().getNumCredencial().equals(prestamo.getUsuario().getNumCredencial())
               && prest.getPublicacion().getIsbn().equals(prest.getPublicacion().getIsbn()))
            {
                existe = true;
                prestamos.set(prestamos.indexOf(prest), prestamo);
                break;
            }
        }
        if(existe == false)throw new DAOException("Prestamo inexistente.");
    }
    /**
     * Elimina al préstamo dado por el
     * parámetro, si existe, de la lista prestamos si sus ISBN y números de credencial
     * coinciden. Si el prestamo no existe, el método lanza una excepción del tipo
     * DAOException.
     * @param prestamo
     * @throws DAOException 
     */
    public void elimina(Prestamo prestamo) throws DAOException{
        int index = prestamos.indexOf(prestamo);
        if(index<0) throw new DAOException("Prestamo inexistente");
        prestamos.remove(index);
    }
    /**
     * Regresan listas de todos los préstamos.
     * @return List prestamos
     */
    public List<Prestamo> lista(){
        return prestamos;
    }
    /**
     * Regresan listas de todos préstamos del mismo usuario.
     * @param usuario
     * @return list publicacion
     */
    public List<Prestamo> lista(Usuario usuario){
        List<Prestamo> listaUsuario = new ArrayList<Prestamo>();
        for(Prestamo p:prestamos)
            if(p.getUsuario().getNumCredencial().equals(usuario.getNumCredencial())){
                listaUsuario.add(p);
        }
        return listaUsuario;
    }
    /**
     * Regresan listas de todos los préstamos de la misma publicación.
     * @param publicacion
     * @return List publicacion
     */
    public List<Prestamo> lista(Publicacion publicacion){
        List<Prestamo> listaPublicacion = new ArrayList<Prestamo>();
        for(Prestamo p:prestamos){
            if(p.getPublicacion().getIsbn().equals(publicacion.getIsbn()))
                listaPublicacion.add(p);
        }
        return listaPublicacion;
    }
    /**
     * Regresan listas de todos los préstamos del mismo periodo.
     * @param periodo
     * @return list prestamo
     */
    public List<Prestamo> lista(Periodo periodo){
        List<Prestamo> listaPeriodo = new ArrayList<Prestamo>();
        for(Prestamo p:prestamos){
            if(p.getPeriodo().equals(periodo))
                listaPeriodo.add(p);
        }
        return listaPeriodo;
    }
}
