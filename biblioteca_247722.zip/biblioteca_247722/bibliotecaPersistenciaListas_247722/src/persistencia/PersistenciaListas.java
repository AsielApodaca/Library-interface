package persistencia;
import java.util.List;
import objetosServicio.*;
import objetosNegocio.*;
import excepciones.*;
import interfaces.IPersistencia;
import dao.*;
/**
 * Clase PersistenciaListas
 * @author Asiel Apodaca Monge 00000247722
 */
public class PersistenciaListas implements IPersistencia{
    private Libros catalogoLibros;
    private Usuarios catalogoUsuarios;
    public PublicacionesED inventarioLibros;
    public Prestamos prestamosLibros;
    /**
     * Constructor general PersistenciaListas
     */
    public PersistenciaListas(){
        catalogoLibros = new Libros();
        catalogoUsuarios = new Usuarios();
        inventarioLibros = new PublicacionesED();
        prestamosLibros = new Prestamos();
    }
    /**
     * El constructor de la clase PersistenciaListas crea objetos del tipo Libros, Usuarios,
     * PublicacionesED y Prestamos, respectivamente. Esos objetos son asignados a los atributos 
     * catalogoLibros, catalogoUsuarios, inventarioLibros y prestamosLibros,
     * respectivamente.
     * @param catalogoLibros
     * @param catalogoUsuarios
     * @param inventarioLibros
     * @param prestamosLibros 
     */
    public PersistenciaListas(Libros catalogoLibros, Usuarios catalogoUsuarios, PublicacionesED inventarioLibros, Prestamos prestamosLibros) {
        this.catalogoLibros = catalogoLibros;
        this.catalogoUsuarios = catalogoUsuarios;
        this.inventarioLibros = inventarioLibros;
        this.prestamosLibros = prestamosLibros;
    }
    /**
     * Obtiene un libro del catalogo de libros.
     * @param libro
     * @return Libro
     * @throws PersistenciaException 
     */
    @Override
    public Libro obten(Libro libro) throws PersistenciaException{
        return catalogoLibros.obten(libro);
    }
    /**
     * Obtiene un Usuario del catalogo de usuarios.
     * @param usuario
     * @return Usuario
     */
    @Override
    public Usuario obten(Usuario usuario){
        return catalogoUsuarios.obten(usuario);
    }
    /**
     * Agrega un Libro al catalogo de Libros, No se permiten libros con claves
     * repetidas.
     * @param libro
     * @throws PersistenciaException 
     */
    @Override
    public void agregar(Libro libro) throws PersistenciaException {
        if(catalogoLibros.obten(libro) != null)
            throw new PersistenciaException("El libro con ISBN "+catalogoLibros.obten(libro).getIsbn()+" ya existe.");
        catalogoLibros.agrega(libro);
    }
    /**
     * Agrega un Usuario al catalogo de Usuarios, No se permiten usuarios con
     * claves repetidas.
     * @param usuario
     * @throws PersistenciaException 
     */
    @Override
    public void agregar(Usuario usuario) throws PersistenciaException {
        if(catalogoUsuarios.obten(usuario) != null)
            throw new PersistenciaException("El usuario con id "+catalogoUsuarios.obten(usuario).getNumCredencial()+" ya existe.");
        catalogoUsuarios.agrega(usuario);
    }
    /**
     * Actualiza un libro del catalogo.
     * @param libro
     * @throws PersistenciaException 
     */
    @Override
    public void actualizar(Libro libro) throws PersistenciaException {
        if(catalogoLibros.obten(libro) == null)
            throw new PersistenciaException("Libro inexistente.");
        catalogoLibros.actualiza(libro);
    }
    /**
     * Actualiza un Usuario del catalogo.
     * @param usuario
     * @throws PersistenciaException 
     */
    @Override
    public void actualizar(Usuario usuario) throws PersistenciaException {
        if(catalogoUsuarios.obten(usuario) == null)
            throw new PersistenciaException("Usuario inexistente.");
        catalogoUsuarios.actualiza(usuario);
    }
    /**
     * Elimina el libro dado por el parámetro.
     * @param libro
     * @throws PersistenciaException 
     */
    @Override
    public void eliminar(Libro libro) throws PersistenciaException {
        if(catalogoLibros.obten(libro) == null)
            throw new PersistenciaException("Libro inexistente.");
        catalogoLibros.elimina(libro);
    }
    /**
     * Elimina el usuario dado por el parámetro.
     * @param usuario
     * @throws PersistenciaException 
     */
    @Override
    public void eliminar(Usuario usuario) throws PersistenciaException {
        if(catalogoUsuarios.obten(usuario) == null)
            throw new PersistenciaException("Usuario inexistente.");
        catalogoUsuarios.elimina(usuario);
    }
    /**
     * Si el libro no existe en el inventario, lo agrega a su inventario,
     * haciendo que la existencia y disponibilidad sean igual al parámetro
     * cantidad, Si el libro ya existe, actualiza el libro, incrementando los
     * atributos existencia y disponibilidad en el valor de parámetro cantidad.
     * @param libro
     * @param cantidad
     * @throws PersistenciaException 
     */
    @Override
    public void inventariar(Libro libro, int cantidad) throws PersistenciaException {
        int existencia = 0;
        int disponibilidad = 0;
        for(PublicacionED publicacionED:inventarioLibros.lista()){
            if(publicacionED.getPublicacion().getIsbn().equals(libro.getIsbn())){
                existencia = publicacionED.getExistencia();
                disponibilidad = publicacionED.getDisponibilidad();
                inventarioLibros.elimina(publicacionED);
                break;
            }
        }
        inventarioLibros.agrega(new PublicacionED(libro,(existencia+cantidad),(disponibilidad+cantidad)));
    }
    /**
     * Actualiza el libro en su inventario de libros, decrementando los
     * atributos existencia y disponibilidad en el valor de parámetro cantidad,
     * Si después de la operación la existencia se hace 0, elimina el libro del
     * inventario.
     * @param libro
     * @param cantidad
     * @throws PersistenciaException 
     */
    @Override
    public void desinventariar(Libro libro, int cantidad) throws PersistenciaException {
        boolean existe = false;
        int index;
        for(PublicacionED publicacionED:inventarioLibros.lista()){
            if(publicacionED.getPublicacion().getIsbn().equals(libro.getIsbn())){
                existe = true;
                if(publicacionED.getExistencia()-cantidad<0||publicacionED.getDisponibilidad()-cantidad<0)
                    throw new PersistenciaException("No hay existencia o disponibilidad suficiente para desinventariar.");
                inventarioLibros.actualiza(new PublicacionED(
                        libro,
                        publicacionED.getExistencia()-cantidad,
                        publicacionED.getDisponibilidad()-cantidad
                ));
                if(inventarioLibros.obten(new PublicacionED(libro)).getExistencia() == 0)
                    inventarioLibros.elimina(inventarioLibros.obten(new PublicacionED(libro)));
                break;
            }
        }
        if(existe == false)
            throw new PersistenciaException("PublicacionED inexistente.");
    }
    /**
     * Registra el préstamo en el registro de préstamos de libros:
     * prestamosLibros y Actualiza la disponibilidad del libro, decrementando el
     * valor del atributo disponibilidad de su inventario.
     * @param prestamo
     * @throws PersistenciaException 
     */
    @Override
    public void prestarLibro(Prestamo prestamo) throws PersistenciaException {
        boolean disponibilidad = false;
        PublicacionED pubED = new PublicacionED(prestamo.getPublicacion());
        for(PublicacionED publicacionED:inventarioLibros.lista()){
            if(publicacionED.getPublicacion().equals(prestamo.getPublicacion())){
                pubED = publicacionED;
                if(publicacionED.getDisponibilidad()>0)
                    disponibilidad = true;
                break;
            }
        }
        if(disponibilidad == false)
            throw new PersistenciaException("Libro no disponible.");
        else if(prestamosLibros.obten(prestamo) != null)
            throw new PersistenciaException("Este libro ya está prestado.");
        prestamosLibros.agrega(prestamo);
        inventarioLibros.actualiza(new PublicacionED(
            pubED.getPublicacion(),
            pubED.getExistencia(),
            (pubED.getDisponibilidad()-1)
        ));
        
    }
    /**
     * Elimina la entrada en prestamosLibros y Actualiza la disponibilidad del
     * libro, incrementando el valor del atributo disponibilidad de su
     * correspondiente inventario.
     * @param prestamo
     * @throws PersistenciaException 
     */
    @Override
    public void devolverLibro(Prestamo prestamo) throws PersistenciaException {
        Prestamo pre = prestamosLibros.obten(prestamo);
        if(pre == null)
            throw new PersistenciaException("Prestamo inexistente.");
        inventarioLibros.actualiza(new PublicacionED(
            pre.getPublicacion(),
            inventarioLibros.obten(new PublicacionED(pre.getPublicacion())).getExistencia(),
            (inventarioLibros.obten(new PublicacionED(pre.getPublicacion())).getDisponibilidad()+1)
        ));
    }
    /**
     * Regresan listas de todos los libros.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Libro> consultarLibros() throws PersistenciaException {
        return catalogoLibros.lista();
    }
    /**
     * Regresan listas de todos los libros con el mismo autor.
     * @param autor
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Libro> consultarLibrosAutor(String autor) throws PersistenciaException {
        return catalogoLibros.listaAutor(autor);
    }
    /**
     * Regresan listas de todos los libros con la misma casa editorial.
     * @param editorial
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Libro> consultarLibrosEditorial(String editorial) throws PersistenciaException {
        return catalogoLibros.listaEditorial(editorial);
    }
    /**
     * Regresan listas de todos los libros con la misma clasificación.
     * @param clasificacion
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Libro> consultarLibrosClasificacion(String clasificacion) throws PersistenciaException {
        return catalogoLibros.listaClasificacion(clasificacion);
    }
    /**
     * Regresa una lista de todos los usuarios.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Usuario> consultarUsuarios() throws PersistenciaException {
        return catalogoUsuarios.lista();
    }
    /**
     * Regresan listas del inventario de libros.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<PublicacionED> consultarInventarioLibros() throws PersistenciaException {
        return inventarioLibros.lista();
    }
    /**
     * Regresan listas de libros prestados.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<PublicacionED> consultarLibrosPrestados() throws PersistenciaException {
        return inventarioLibros.listaPrestada();
    }
    /**
     * Regresan la lista de libros disponibles.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<PublicacionED> consultarLibrosDisponibles() throws PersistenciaException {
        return inventarioLibros.listaDisponibles();
    }
    /**
     * Regresan listas de todos los préstamos de libros.
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Prestamo> consultarPrestamosLibros() throws PersistenciaException {
        return prestamosLibros.lista();
    }
    /**
     * Regresan listas de los préstamos de libros del mismo usuario.
     * @param usuario
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Prestamo> consultarPrestamosLibros(Usuario usuario) throws PersistenciaException {
        return prestamosLibros.lista(usuario);
    }
    /**
     * Regresan listas de los préstamos de libros del mismo libro
     * @param libro
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Prestamo> consultarPrestamos(Libro libro) throws PersistenciaException {
        return prestamosLibros.lista(libro);
    }
    /**
     * Regresan listas de los préstamos de libros del mismo periodo
     * @param periodo
     * @return Lista
     * @throws PersistenciaException 
     */
    @Override
    public List<Prestamo> consultarPrestamosLibros(Periodo periodo) throws PersistenciaException {
        return prestamosLibros.lista(periodo);
    }
}
