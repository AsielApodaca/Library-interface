package interfaces;
import objetosNegocio.*;
import objetosServicio.*;
import excepciones.*;
import java.util.List;

/**
 * Interfaz
 * @author Asiel Apodaca Monge
 */
public interface IPersistencia {
    /**
     * @param libro
     * @return Obtienen un libro de sus respectivos catálogos cuyos ISBN o número de
     * credencial coincidan con los ISBN o número de credencial contenidos en sus parámetros. Si
     * no se encuentran regresan null.
     * @throws PersistenciaException 
     */
    public Libro obten(Libro libro) throws PersistenciaException;
    /**
     * @param Usuario
     * @return Obtienen un usuario de sus respectivos catálogos cuyos ISBN o número de
     * credencial coincidan con los ISBN o número de credencial contenidos en sus parámetros. Si
     * no se encuentran regresan null.
     * @throws PersistenciaException 
     */
    public Usuario obten(Usuario Usuario) throws PersistenciaException;
    /**
     * Agrega el libro dado por el parámetro, si no existe, a su correspondiente catálogo.
     * Si ya existe o no se puede agregar el libro o usuario lanzan una excepción del tipo
     * PersistenciaException.
     * @param libro
     * @throws PersistenciaException 
     */
    public void agregar(Libro libro) throws PersistenciaException;
    /**
     * Agrega el usuario dado por el parámetro, si no existe, a su correspondiente catálogo.
     * Si ya existe o no se puede agregar el libro o usuario lanzan una excepción del tipo
     * PersistenciaException.
     * @param usuario
     * @throws PersistenciaException 
     */
    public void agregar(Usuario usuario) throws PersistenciaException;
    /**
     * Actualiza el libro dado por el parámetro, si existe, de su correspondiente catálogo.
     * Si no existe o no se puede actualizar el libro o usuario lanzan una excepción del tipo
     * PersistenciaException.
     * @param libro
     * @throws PersistenciaException 
     */
    public void actualizar(Libro libro) throws PersistenciaException;
    /**
     * Actualiza el usuario dado por el parámetro, si existe, de su correspondiente catálogo.
     * Si no existe o no se puede actualizar el libro o usuario lanzan una excepción del tipo
     * PersistenciaException.
     * @param usuario
     * @throws PersistenciaException 
     */
    public void actualizar(Usuario usuario) throws PersistenciaException;
    /**
     * Elimina el libro dado por el parámetro, de su correspondiente catálogo. Si no existe
     * o no se puede eliminar el libro o
     * @param libro
     * @throws PersistenciaException 
     */
    public void eliminar(Libro libro) throws PersistenciaException;
    /**
     * Elimina el usuario dado por el parámetro, de su correspondiente catálogo. Si no existe
     * o no se puede eliminar el libro o
     * @param usuario
     * @throws PersistenciaException 
     */
    public void eliminar(Usuario usuario) throws PersistenciaException;
    /**
     * a) Si el libro no existe en el inventario, lo agrega a su inventario, haciendo que la
     *    existencia y disponibilidad sean igual al parámetro cantidad.
     * b) Si el libro ya existe, actualiza el libro, incrementando los atributos existencia y
     *    disponibilidad en el valor de parámetro cantidad.
     * @param libro
     * @param cantidad
     * @throws PersistenciaException 
     */
    public void inventariar(Libro libro , int cantidad) throws PersistenciaException;
    /**
     * 
     * @param libro
     * @param cantidad
     * @throws PersistenciaException 
     */
    public void desinventariar(Libro libro, int cantidad) throws PersistenciaException;
    /**
     * a) Si el libro no existe en el inventario o no hay suficientes en existencia o
     *    disponibilidad, lanza una excepción del tipo PersistenciaException.
     * b) Actualiza el libro en su inventario de libros, decrementando los atributos
     *    existencia y disponibilidad en el valor de parámetro cantidad.
     * c) Si después de la operación la existencia se hace 0, elimina el libro del inventario.
     * @param prestamo
     * @throws PersistenciaException 
     */
    public void prestarLibro(Prestamo prestamo) throws PersistenciaException;
    /**
     * c) Si el libro no existe o no está disponible en el inventario, lanza una excepción del tipo
     *    PersistenciaException.
     * d) Si el libro ya está prestado al usuario, lanza una excepción del tipo
     *    PersistenciaException.
     * e) Registra el préstamo en el registro de préstamos de libros: prestamosLibros.
     * f) Actualiza la disponibilidad del libro, decrementando el valor del atributo
     *    disponibilidad de su inventario.
     * @param prestamo
     * @throws PersistenciaException 
     */
    public void devolverLibro(Prestamo prestamo) throws PersistenciaException;
    /**
     * Regresan listas de todos los libros, Si no se puede acceder al catálogo de libros lanzan
     * una excepción del tipo PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<Libro> consultarLibros()throws PersistenciaException;
    /**
     * Regresan listas de todos los libros con el mismo autor, Si no se puede acceder al catálogo de libros lanzan
     * una excepción del tipo PersistenciaException.
     * @param autor
     * @return
     * @throws PersistenciaException 
     */
    public List<Libro> consultarLibrosAutor(String autor) throws PersistenciaException;
    /**
     * Regresan listas de todos los libros con la misma editorial, Si no se puede acceder al catálogo de libros lanzan
     * una excepción del tipo PersistenciaException.
     * @param editorial
     * @return
     * @throws PersistenciaException 
     */
    public List<Libro> consultarLibrosEditorial(String editorial) throws PersistenciaException;
    /**
     * Regresan listas de todos los libros con la misma clasificación, Si no se puede acceder al catálogo de libros lanzan
     * una excepción del tipo PersistenciaException.
     * @param clasificacion
     * @return
     * @throws PersistenciaException 
     */
    public List<Libro> consultarLibrosClasificacion(String clasificacion) throws PersistenciaException;
    /**
     * Regresa una lista de todos los usuarios. Si no se puede acceder al catálogo de usuarios lanzan una
     * excepción del tipo PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<Usuario> consultarUsuarios() throws PersistenciaException;
    /**
     * Regresan listas del inventario de libros. Si
     * no se puede acceder al inventario de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<PublicacionED> consultarInventarioLibros() throws PersistenciaException;
    /**
     * Regresan listas de libros prestados. Si
     * no se puede acceder al inventario de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<PublicacionED> consultarLibrosPrestados() throws PersistenciaException;
    /**
     * Regresan listas de libros disponibles. Si
     * no se puede acceder al inventario de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<PublicacionED> consultarLibrosDisponibles() throws PersistenciaException;
    /**
     * Regresan listas de todos los préstamos de libros. Si no se puede
     * acceder al registro de préstamos de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @return
     * @throws PersistenciaException 
     */
    public List<Prestamo> consultarPrestamosLibros()throws PersistenciaException;
    /**
     * Regresan listas de todos los préstamos de libros del mismo usuario. Si no se puede
     * acceder al registro de préstamos de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @param usuario
     * @return
     * @throws PersistenciaException 
     */
    public List<Prestamo> consultarPrestamosLibros(Usuario usuario) throws PersistenciaException;
    /**
     * Regresan listas de todos los préstamos de libros del mismo autor. Si no se puede
     * acceder al registro de préstamos de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @param libro
     * @return
     * @throws PersistenciaException 
     */
    public List<Prestamo> consultarPrestamos(Libro libro) throws PersistenciaException;
    /**
     * Regresan listas de todos los préstamos de libros del mismo periodo. Si no se puede
     * acceder al registro de préstamos de libros lanzan una excepción del tipo
     * PersistenciaException.
     * @param periodo
     * @return
     * @throws PersistenciaException 
     */
    public List<Prestamo> consultarPrestamosLibros(Periodo periodo) throws PersistenciaException;
}