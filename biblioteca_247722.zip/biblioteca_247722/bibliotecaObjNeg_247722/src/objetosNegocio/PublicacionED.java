package objetosNegocio;
import java.util.Objects;
/**
 * Clase PublicacionED de la librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class PublicacionED {
    private Publicacion publicacion;
    private int existencia,disponibilidad;
    /**
     * Constructor general tipo PublicacionED.
     */
    public PublicacionED(){}
    /**
     * Constructor PublicacionED
     * @param publicacion Valor necesario para crear objeto.
     * @param existencia Valor necesario para crear objeto.
     * @param disponibilidad Valor necesario para crear objeto.
     */
    public PublicacionED(Publicacion publicacion, int existencia, int disponibilidad) {
        this.publicacion = publicacion;
        this.existencia = existencia;
        this.disponibilidad = disponibilidad;
    }
    /**
     * Constructor PublicacionED
     * @param publicacion Valor necesario para crear objeto.
     */
    public PublicacionED(Publicacion publicacion) {
        this.publicacion = publicacion;
    }
    /**
     * Método getPublicacion
     * @return Retorna publicacion.
     */
    public Publicacion getPublicacion() {
        return publicacion;
    }
    /**
     * Método setPublicacion
     * @param publicacion Guarda publicacion.
     */
    public void setPublicacion(Publicacion publicacion) {
        this.publicacion = publicacion;
    }
    /**
     * Método getExistencia
     * @return retorna existencia.
     */
    public int getExistencia() {
        return existencia;
    }
    /**
     * Método setExistencia
     * @param existencia guarda existencia.
     */
    public void setExistencia(int existencia) {
        this.existencia = existencia;
    }
    /**
     * Método getDisponibilidad
     * @return Retorna disponibilidad.
     */
    public int getDisponibilidad() {
        return disponibilidad;
    }
    /**
     * Método setDisponibilidad
     * @param disponibilidad Retorna disponibilidad.
     */
    public void setDisponibilidad(int disponibilidad) {
        this.disponibilidad = disponibilidad;
    }
    /**
     * Método hashCode
     * @return Retorna hash.
     */
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    /**
     * Método equals
     * @param obj Valor necesario para comparar.
     * @return Retorna Boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PublicacionED other = (PublicacionED) obj;
        return Objects.equals(this.publicacion, other.publicacion);
    }
    /**
     * Método toString
     * @return Retorna valores de parámetros.
     */
    @Override
    public String toString() {
        return publicacion+","+existencia+","+disponibilidad;
    }
    
    
    
}
