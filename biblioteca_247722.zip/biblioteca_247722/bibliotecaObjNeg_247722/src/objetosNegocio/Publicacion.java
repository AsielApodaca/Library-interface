package objetosNegocio;
import java.util.Objects;

/**
 * Clase Publicación de librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class Publicacion {
    protected String isbn,titulo,editorial,clasificacion;
    /**
     * Constructor general tipo Publicacion.
     */
    public Publicacion(){}
    /**
     * Constructor tipo Publicacion que recibe todos los parámetros.
     * @param isbn Parámetro tipo String necesario para ejecutar constructor.
     * @param titulo Parámetro tipo String necesario para ejecutar constructor.
     * @param editorial Parámetro tipo String necesario para ejecutar constructor.
     * @param clasificacion Parámetro tipo String necesario para ejecutar constructor.
     */
    public Publicacion(String isbn, String titulo, String editorial, String clasificacion) {
        this.isbn = isbn; 
        this.titulo = titulo;
        this.editorial = editorial;
        this.clasificacion = clasificacion;
    }
    /**
     * Constructor tipo Publicacion que solo recibe el parámetro Isbn.
     * @param isbn Parámetro tipo String necesario para ejecutar constructor.
     */
    public Publicacion(String isbn){
        this.isbn = isbn;
        this.titulo = null;
        this.editorial = null;
        this.clasificacion = null;
    }
    /**
     * Método Get que retorna valor tipo String de isbn.
     * @return Retorna String de isbn
     */
    public String getIsbn() {
        return isbn;
    }
    /**
     * Método Set que guarda valor tipo String de isbn.
     * @param isbn Valor necesario para ejecutar Set.
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    /**
     * Método get que retorna valor tipo String de Titulo.
     * @return Retorna String de título.
     */
    public String getTitulo() {
        return titulo;
    }
    /**
     * Método Set que guarda valor tipo String de Titulo.
     * @param titulo Valor necesario para ejecutar Set.
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    /**
     * Método Get que retorna valor tipo String de Editorial.
     * @return Retorna String de Editorial.
     */
    public String getEditorial() {
        return editorial;
    }
    /**
     * Método Set que guarda valor tipo String de Editorial.
     * @param editorial Valor necesario para ejecutar Set.
     */
    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }
    /**
     * Método Get que retorna valor tipo String de Clasificacion.
     * @return Retorna String de Clasificacion.
     */
    public String getClasificacion() {
        return clasificacion;
    }
    /**
     * Método Set que guarda valor tipo String de Clasificacion.
     * @param clasificacion Valor necesario para ejecutar Set.
     */
    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }
    /**
     * Método que Hashea isbn.
     * @return Retorna valor tipo int.
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.isbn);
        return hash;
    }
    /**
     * Método que retorna valor tipo Boolean que compara igualdad de clases.
     * @param obj Valor necesario para comparar clases.
     * @return Retorna valor Boolean.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Publicacion other = (Publicacion) obj;
        return Objects.equals(this.isbn, other.isbn);
    }
    /**
     * Método toString
     * @return Retorna valor de parámetros.
     */
    @Override
    public String toString() {
        return isbn+","+titulo+","+editorial+","+clasificacion;
    }
    
    
    
    
}
