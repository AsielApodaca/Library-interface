package objetosNegocio;

import java.util.Objects;

/**
 * Clase Usuario de la librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class Usuario {
    private String numCredencial,nombre,direccion,telefono;
    /**
     * Constructor general Usuario
     */
    public Usuario(){}
    /**
     * Constructor Usuario
     * @param numCredencial Valor necesario para crear objeto.
     * @param nombre Valor necesario para crear objeto.
     * @param direccion Valor necesario para crear objeto.
     * @param telefono Valor necesario para crear objeto.
     */
    public Usuario(String numCredencial, String nombre, String direccion, String telefono) {
        this.numCredencial = numCredencial;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }
    /**
     * Constructor Usuario.
     * @param numCredencial Valor necesario para crear objeto.
     */
    public Usuario(String numCredencial) {
        this.numCredencial = numCredencial;
    }
    /**
     * Método getNumCredencial
     * @return Retorna numCredencial.
     */
    public String getNumCredencial() {
        return numCredencial;
    }
    /**
     * Método setNumCredencial
     * @param numCredencial Guarda numCredencial.
     */
    public void setNumCredencial(String numCredencial) {
        this.numCredencial = numCredencial;
    }
    /**
     * Método getNombre
     * @return Retorna nombre;
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Método setNombre
     * @param nombre guarda nombre.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Método getDireccion
     * @return Retorna direccion.
     */
    public String getDireccion() {
        return direccion;
    }
    /**
     * Método setDireccion
     * @param direccion Guarda direccion.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    /**
     * Método getTelefono
     * @return Retorna telefono.
     */
    public String getTelefono() {
        return telefono;
    }
    /**
     * Método setTelefono
     * @param telefono Guarda telefono.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    /**
     * Método HashCode
     * @return Retorna Hash.
     */
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    /**
     * Método equals.
     * @param obj Valor necesario para comparar.
     * @return Retorna Boolean.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return Objects.equals(this.numCredencial, other.numCredencial);
    }
    /**
     * Método toString
     * @return Retorna valor de parámetros.
     */
    @Override
    public String toString() {
        return "Usuario{" + "numCredencial=" + numCredencial + ", nombre=" + nombre + ", direccion=" + direccion + ", telefono=" + telefono + '}';
    }
    
}