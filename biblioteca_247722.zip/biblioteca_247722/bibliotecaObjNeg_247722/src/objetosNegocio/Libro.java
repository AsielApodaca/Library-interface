package objetosNegocio;
/**
 * Clase Libro heredado de la clase Publicacion de la librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class Libro extends Publicacion{
    private String autor,edicion;
    /**
     * Constructor general de clase Libro.
     */
    public Libro(){
        super(null,null,null,null);
        this.autor = null;
        this.edicion = null;
    }
    /**
     * Constructor clase Libro que almacena todos los parámetros.
     * @param autor Valor del padre tipo String necesario para generar constructor.
     * @param edicion Valor del padre tipo String necesario para generar constructor.
     * @param isbn Valor del padre tipo String necesario para generar constructor.
     * @param titulo Valor del padre tipo String necesario para generar constructor.
     * @param editorial Valor tipo String necesario para generar constructor.
     * @param clasificacion  Valor tipo String necesario para generar constructor.
     */
    public Libro(String isbn, String titulo, String editorial, String clasificacion, String autor, String edicion) {
        super(isbn, titulo, editorial, clasificacion);
        this.autor = autor;
        this.edicion = edicion;
    }
    /**
     * Constructor clase Libro que almacena unicamente valor String isbn.
     * @param isbn Valor necesario para generar constructor.
     */
    public Libro(String isbn) {
        super(isbn,null,null,null);
        this.autor = null;
        this.edicion = null;
    }
    /**
     * Método Get que retorna valor tipo String de autor.
     * @return Retorna String autor.
     */
    public String getAutor() {
        return autor;
    }
    /**
     * Método Set que guarda valor tipo String de Autor.
     * @param autor Valor necesario para ejecutar Set.
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }
    /**
     * Método Get que retorna valor tipo String de Edicion.
     * @return Retorna String de Edicion.
     */
    public String getEdicion() {
        return edicion;
    }
    /**
     * Método Set que guarda valor tipo String de Edicion.
     * @param edicion Valor necesario para ejecutar Set.
     */
    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }
    /**
     * Método Get que retorna valor de los parámetros de la clase
     * @return Retorna String de parámetros.
     */
    @Override
    public String toString() {
        return super.isbn+","+super.titulo+","+super.editorial+","+super.clasificacion+","+autor+","+edicion;
    }  
}
