package objetosNegocio;
import objetosServicio.Fecha;
/**
 * Clase Revista heredado de la clase Publicacion de la librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class Revista extends Publicacion{
    private String periodicidad;
    private Fecha fecha;
    /**
     * Constructor general de clase Revista.
     */
    public Revista(){
        super(null,null,null,null);
        this.periodicidad = null;
        this.fecha = null;
    }
    /**
     * Constructor clase Revista que almacena todos los parámetros.
     * @param periodicidad Valor tipo String necesario para generar constructor.
     * @param fecha Valor tipo Fecha necesario para generar constructor.
     * @param isbn Valor del padre tipo String necesario para generar constructor.
     * @param titulo Valor del padre tipo String necesario para generar constructor.
     * @param editorial Valor del padre tipo String necesario para generar constructor.
     * @param clasificacion  Valor del padre tipo String necesario para generar constructor.
     */
    public Revista(String isbn, String titulo, String editorial, String clasificacion, String periodicidad, Fecha fecha) {
        super(isbn, titulo, editorial, clasificacion);
        this.periodicidad = periodicidad;
        this.fecha = fecha;
    }
    /**
     * Constructor clase Revista que almacena unicamente valor String isbn.
     * @param isbn Valor necesario para generar constructor.
     */
    public Revista(String isbn) {
        super(isbn,null,null,null);
        this.periodicidad = null;
        this.fecha = null;
    }
    /**
     * Método Get que retorna valor tipo String de periodicidad.
     * @return Retorna String periodicidad.
     */
    public String getPeriodicidad() {
        return periodicidad;
    }
    /**
     * Método Set que guarda valor tipo String de periodicidad.
     * @param periodicidad Valor necesario para ejecutar Set.
     */
    public void setPeriodicidad(String periodicidad) {
        this.periodicidad = periodicidad;
    }
    /**
     * Método Get que retorna valor tipo String de Edicion.
     * @return Retorna String de Edicion.
     */
    public Fecha getFecha() {
        return fecha;
    }
    /**
     * Método Set que guarda valor tipo String de Edicion.
     * @param fecha Valor necesario para ejecutar Set.
     */
    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }
    /**
     * Método Get que retorna valor de los parámetros de la clase
     * @return Retorna String de parámetros.
     */
    @Override
    public String toString() {
        return super.isbn+","+super.titulo+","+super.editorial+","+super.clasificacion+","+periodicidad+","+fecha;
    }  
}
