package objetosNegocio;
import java.util.Objects;
import objetosServicio.*;
/**
 * Clase Prestamo de la librería objetosNegocio
 * @author Asiel Apodaca Monge 00000247722
 */
public class Prestamo {
    private Usuario usuario;
    private Publicacion publicacion;
    private Fecha fechaPrestamo;
    private int tiempoPrestamo;
    /**
     * Constructor general Prestamo
     */
    public Prestamo(){}
    /**
     * Constructor Prestamo
     * @param usuario Valor necesario para crear objeto.
     * @param publicacion Valor necesario para crear objeto.
     * @param fechaPrestamo Valor necesario para crear objeto.
     * @param tiempoPrestamo Valor necesario para crear objeto.
     */
    public Prestamo(Usuario usuario, Publicacion publicacion, Fecha fechaPrestamo, int tiempoPrestamo) {
        this.usuario = usuario;
        this.publicacion = publicacion;
        this.fechaPrestamo = fechaPrestamo;
        this.tiempoPrestamo = tiempoPrestamo;
    }
    /**
     * Constructor Prestamo
     * @param usuario Valor necesario para crear objeto.
     * @param publicacion Valor necesario para crear objeto.
     */
    public Prestamo(Usuario usuario, Publicacion publicacion) {
        this.usuario = usuario;
        this.publicacion = publicacion;
    }
    /**
     * Método getUsuario
     * @return Retorna usuario.
     */
    public Usuario getUsuario() {
        return usuario;
    }
    /**
     * Método setUsuario
     * @param usuario Guarda valor usuario.
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    /**
     * Método getPublicacion
     * @return retorna publicacion.
     */
    public Publicacion getPublicacion() {
        return publicacion;
    }
    /**
     * Método setPublicacion
     * @param publicacion guarda valor de publicacion.
     */
    public void setPublicacion(Publicacion publicacion) {
        this.publicacion = publicacion;
    }
    /**
     * Método getFechaPrestamo
     * @return Retorna valor de fechaPrestamo.
     */
    public Fecha getFechaPrestamo() {
        return fechaPrestamo;
    }
    /**
     * Método setFechaPrestamo
     * @param fechaPrestamo Guarda fechaPrestamo.
     */
    public void setFechaPrestamo(Fecha fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }
    /**
     * Método getTiempoPrestamo
     * @return retorna tiempoPrestamo.
     */
    public int getTiempoPrestamo() {
        return tiempoPrestamo;
    }
    /**
     * Método setTiempoPrestamo
     * @param tiempoPrestamo guarda valor tiempoPrestamo.
     */
    public void setTiempoPrestamo(int tiempoPrestamo) {
        this.tiempoPrestamo = tiempoPrestamo;
    }
    /**
     * Método que retorna Periodo
     * @return Periodo
     */
    public Periodo getPeriodo(){
        return new Periodo(fechaPrestamo,new Fecha(fechaPrestamo.vencimiento(tiempoPrestamo)));
    }
    /**
     * Genera Hash
     * @return retorna hash.
     */
    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }
    /**
     * Compara clase con clase Prestamo
     * @param obj Objeto necesario para comparar.
     * @return Retorna boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Prestamo other = (Prestamo) obj;
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return Objects.equals(this.publicacion, other.publicacion);
    }
    /**
     * Método toString
     * @return Retorna valor de parámetros.
     */
    @Override
    public String toString() {
        return "Prestamo{" + "usuario=" + usuario + ", publicacion=" + publicacion + ", fechaPrestamo=" + fechaPrestamo + ", tiempoPrestamo=" + tiempoPrestamo + '}';
    }
    
    
}
