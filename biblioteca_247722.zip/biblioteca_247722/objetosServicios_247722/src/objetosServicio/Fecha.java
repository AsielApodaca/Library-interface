package objetosServicio;
import java.util.GregorianCalendar;
/**
 * Clase Fecha extendida de GregorianCalendar de proyecto tipo Java Class Library.
 * @author Asiel Apodaca Monge
 * @version 1.0
 * @serial 00000247722
 */
public class Fecha extends GregorianCalendar{
    private int anho,mes,dia,hora,minuto,segundo,milisegundo;
    private Fecha fecha;
    /**
     * Constructor general de Fecha.
     */
    public Fecha(){
        super();
        this.set(this.HOUR,0);
        this.set(this.MINUTE,0);
        this.set(this.SECOND,0);
        this.set(this.MILLISECOND,0);
    }
    /**
     * Contructor de Fecha que settea valores.
     * @param anho Valor tipo int necesario para ejecutar constructor.
     * @param mes Valor tipo int necesario para ejecutar constructor.
     * @param dia Valor tipo int necesario para ejectuar constructor.
     */
    public Fecha(int anho,int mes,int dia){
        super(anho,mes,dia);
        this.set(this.HOUR,0);
        this.set(this.MINUTE,0);
        this.set(this.SECOND,0);
        this.set(this.MILLISECOND,0);
    }
    /**
     * Constructor de Fecha que settea valor tipo Fecha.
     * @param fecha Valor tipo Fecha necesrio para ejecutar constructor.
     */
    public Fecha(Fecha fecha){
        super(
            fecha.get(fecha.YEAR),
            fecha.get(fecha.MONTH),
            fecha.get(fecha.DAY_OF_MONTH)
        );
        this.set(this.HOUR,0);
        this.set(this.MINUTE,0);
        this.set(this.SECOND,0);
        this.set(this.MILLISECOND,0);
        
    }
    /**
     * Constructor de Fecha que settea valores a fecha.
     * @param fecha Recibe string y convierte en int sus valores.
     */
    public Fecha(String fecha){
        super(
             Integer.parseInt(fecha.split("/")[2]),
             Integer.parseInt(fecha.split("/")[1])-1,
             Integer.parseInt(fecha.split("/")[0])
        );
        this.set(this.HOUR,0);
        this.set(this.MINUTE,0);
        this.set(this.SECOND,0);
        this.set(this.MILLISECOND,0);
    }
    //Setters
    /**
     * Método para settear valor tipo Fecha a la fecha.
     * @param fecha valor tipo Fecha necesario para settear método.
     */
    public void setFecha(Fecha fecha){
        super.set(YEAR, fecha.get(YEAR));
        super.set(MONTH, fecha.get(MONTH));
        super.set(DAY_OF_MONTH, fecha.get(DAY_OF_MONTH));
    }
    /**
     * Método para settear valores tipo int a Fecha
     * @param anho Valor tipo int necesario para settear fecha.
     * @param mes Valor tipo int necesario para settear fecha.
     * @param dia Valor tipo int necesario para settear fecha.
     */
    public void setFecha(int anho,int mes,int dia){
        super.set(YEAR, anho);
        super.set(MONTH, mes-1);
        super.set(DAY_OF_MONTH, dia);
        this.set(this.HOUR,0);
        this.set(this.MINUTE,0);
        this.set(this.SECOND,0);
        this.set(this.MILLISECOND,0);
    }
    /**
     * Este método settea el valor tipo int "anho".
     * @param anho Valor tipo int necesario para hacer funcionar setteo.
     */
    public void setAnho(int anho){
        super.set(YEAR,anho);
    }
    /**
     * Este método settea el valor tipo int "mes".
     * @param mes Valor tipo int necesario para hacer funcionar setteo.
     */
    public void setMes(int mes){
        super.set(MONTH,mes-1);
    }
    /**
     * Este método settea el valor tipo int "dia".
     * @param dia Valor tipo int necesario para hacer funcionar setteo.
     */
    public void setDia(int dia){
        super.set(DAY_OF_MONTH,dia);
    }
    //Getters
    /**
     * Este método retorna el valor tipo int de "YEAR".
     * @return retorna un int.
     */
    public int getAnho(){
        return super.get(YEAR);
    }
    /**
     * Este método retorna el valor tipo int de "MONTH".
     * @return retorna un int.
     */
    public int getMes(){
        return super.get(MONTH)+1;
    }
    /**
     * Este método retorna el valor tipo int de "DAY_OF_MONTH".
     * @return retorna un int.
     */
    public int getDia(){
        return super.get(DAY_OF_MONTH);
    }
    /**
     * Este método retorna un valor tipo Fecha, calcula fecha de vencimiento.
     * @param anho Valor tipo int necesario para retornar Fecha.
     * @param mes Valor tipo int necesario para retornar Fecha.
     * @param dia Valor tipo int necesario para retornar Fecha.
     * @return retorna valor tipo Fecha de fecha calculada de vencimiento.
     */
    public Fecha vencimiento(int anho,int mes, int dia){
        Fecha f = new Fecha(fecha);
        f.add(YEAR,anho);
        f.add(MONTH,mes);
        f.add(DAY_OF_MONTH,dia);
        return f;
    }
    /**
     * Este método retorna un valor tipo Fecha, calcula fecha de vencimiento.
     * @param dia Valor tipo int necesario para retornar Fecha.
     * @param mes Valor tipo int necesario para retornar Fecha.
     * @return retorna valor tipo Fecha de fecha calculada de vencimiento.
     */
    public Fecha vencimiento(int dia,int mes){
        Fecha f = new Fecha(fecha);
        f.add(MONTH,mes);
        f.add(DAY_OF_MONTH,mes);
        return f;
    }
    /**
     * Este método retorna un valor tipo Fecha, calcula fecha de vencimiento.
     * @param dia Valor tipo int necesario para retornar Fecha.
     * @return retorna valor tipo Fecha de fecha calculada de vencimiento.
     */
    public Fecha vencimiento(int dia){
        Fecha f = new Fecha(super.get(YEAR),super.get(MONTH),super.get(DAY_OF_MONTH));
        f.add(DAY_OF_MONTH,dia);
        return f;
    }
    /**
     * Método que regresa lapso entreo dos fechas
     * @param fecha1
     * @param fecha2
     * @return Retorna lapso
     */
    public int lapso(Fecha fecha1,Fecha fecha2){
        return (int)((fecha2.getTimeInMillis()-fecha1.getTimeInMillis())/(1000*60*60*24));
    }
    /**
     * Este método sobreescrito regresa un String con formato de fecha.
     * @return Retorna String con formato de fecha DD/MMM/YYYY
     */
    @Override
    public String toString(){
        return getDia()+"/"+getMes()+"/"+getAnho();
    }
}
