package objetosServicio;
import java.util.GregorianCalendar;

/**
 * Clase Periodo extendida de GregorianCalendar de proyecto tipo Java Class Library.
 * @author Asiel Apodaca Monge
 * @version 1.0
 * @serial 00000247722
 */
public class Periodo extends GregorianCalendar{
    private Fecha desde,hasta;
    /**
     * Constructor general de Periodo
     */
    public Periodo(){
    }
    /**
     * Este es un constructor de periodo
     * @param desde Valor requerido para costruir método
     * @param hasta Valor requerido para construir método
     */
    public Periodo(Fecha desde, Fecha hasta){
        this.desde = desde;
        this.hasta = hasta;
    }
    //Setters
    /**
     * Este método settea el valor tipo Fecha "desde"
     * @param desde Valor necesario para realizar el setteo
     */
    public void setDesde(Fecha desde){
        this.desde = desde;
    }
    /**
     * Este método settea el valor tipo Fecha "hasta"
     * @param hasta Valor necesario para realizar el setteo
     */
    public void setHasta(Fecha hasta){
        this.hasta = hasta;
    }
    /**
     * Este método retorna el valor tipo Fecha "desde"
     * @return desde
     */
    public Fecha getDesde(){
        return desde;
    }
    /**
     * Este método retorna el valor tipo Fecha "hasta"
     * @return hasta
     */
    public Fecha getHasta() {
        return hasta;
    }
    /**
     * Este método regresa un valor booleano
     * @param fecha valor necesario para regresar el booleano
     * @return regresa un valor booleano
     */
    public boolean contiene(Fecha fecha) {
        return !(fecha.before(desde) || fecha.after(hasta));
    }
    public String toString(){
        return "desde "+desde.toString()+" hasta "+hasta.toString();
    }
}
