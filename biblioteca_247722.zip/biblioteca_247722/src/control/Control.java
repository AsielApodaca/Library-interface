package control;
import interfaces.IPersistencia;
import excepciones.*;
import interfazUsuario.*;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import objetosNegocio.*;
import objetosServicio.*;
import persistencia.PersistenciaListas;
/**
 * Clase Control
 * @author Asiel Apodaca Monge 00000247722
 */
public class Control {
    
    IPersistencia persistencia;
    Conversiones conversiones;
    
    /**
     * Constructor general
     */
    public Control(){
        persistencia = new PersistenciaListas();
        conversiones = new Conversiones();
    }
    /**
     * Agrega un Libro al catalogo de Libros.
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del libro.
     * @return Regresa true si se pudo agregar el libro, false en caso contrario.
     */
    public boolean agregarLibro(JFrame frame){
        DlgLibro dlgLibro;
        Libro libro;
        StringBuffer respuesta = new StringBuffer("");
        String ISBN = JOptionPane.showInputDialog(frame,
                "ISBN del libro.","agregar Libro",JOptionPane.QUESTION_MESSAGE);
        if(ISBN == null)return false; //Cancelar
        if(ISBN.isEmpty()){ // No puso identificación.
            JOptionPane.showMessageDialog(null, "Debes agregar identificación para crear un libro.",
                    "Error. ",JOptionPane.ERROR_MESSAGE);
            return false;
        }else{ //Crea libro
            libro = new Libro(ISBN);
        }
        try{
            if(libro.getIsbn() != null){
                persistencia.agregar(libro);
            }else{
                return false;
            }
            dlgLibro = new DlgLibro(frame, "Captura Datos Libro.", true,
                    libro, ConstantesGUI.AGREGAR, respuesta);
            if(respuesta.substring(0).equals(ConstantesGUI.CANCELAR) || libro.getAutor() == null){
                persistencia.eliminar(libro);
                return false;
            }     
        }catch(Exception e){
            /**
             * Despliega error si ocurrió algo en el catálogo de libros.
             */
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error. ",
                    JOptionPane.ERROR_MESSAGE);
            libro = persistencia.obten(libro);
            dlgLibro = new DlgLibro(frame, "Libro existente.", true,libro, ConstantesGUI.DESPLEGAR, respuesta);
            return true;
        }
        return true;
    }
    
    /**
     * Actualiza un libro del catalogo de Libros.
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * editar los datos del libro.
     * @return Regresa true si se pudo actualizar el libro, false en caso
     * contrario
     */
    public boolean actualizarLibro(JFrame frame){
        Libro libro = new Libro();
        StringBuffer respuesta = new StringBuffer("");
        DlgLibro dlgLibro;
        // Captura la clave del libro. 
        String clave = JOptionPane.showInputDialog(frame, "ISBN del Libro.",
                "Actualizar Libro",
                JOptionPane.QUESTION_MESSAGE);
        // Si el usuario presiono el boton Cancelar 
        if (clave == null) {
            return false;
        }
        // Crea un objeto Libro con solo la clave 
        libro = new Libro(clave);

        try {
            // Obten la libro del catalogo de libros 
            libro = persistencia.obten(libro);
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Si el libro no existe, despliega un mensaje de error 
        if (libro == null) {
            JOptionPane.showMessageDialog(frame,
                    "El libro no existe", "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Si el libro existe, edita los datos del libro. 
        dlgLibro = new DlgLibro(frame, "Edita Datos Libro.", true, libro,
                ConstantesGUI.ACTUALIZAR, respuesta);
        // Si el usuario presiono el boton Cancelar 
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }
        // Actualiza el libro del catalogo de Libros. 
        try {
            persistencia.actualizar(libro);
        } catch (Exception e) {
            // Si ocurrio un error al escribir al catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Elimina un libro del catalogo de libros
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * desplegar los datos del libro.
     * @return Regresa true si se pudo eliminar el libro, false en caso
     * contrario
     */
    public boolean eliminarLibro(JFrame frame) {
        Libro libro = new Libro(), bLibro;
        StringBuffer respuesta = new StringBuffer();
        DlgLibro dlgLibro;
        List<Libro> listaLibrosAutor;
        List<Libro> listaLibros;
        String ISBN = JOptionPane.showInputDialog(frame, "ISBN del Libro.",
                "Eliminar Libro",
                JOptionPane.QUESTION_MESSAGE);
        if (ISBN == null) { //Cancelar
            return false;
        }
        libro = new Libro(ISBN); //Crea libro

        try {
            // Obtiene el libro del catalogo de libros 
            bLibro = persistencia.obten(libro);

        } catch (Exception e) {
            // Si ocurrio un error al leer del catalogo de libros 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error. ",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Si el libro no existe en el catalogo de libros, 
        if (bLibro == null) {
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, "El libro no existe.",
                    "Error. ", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Si existe el libro, despliega los datos del libro. 
        dlgLibro = new DlgLibro(frame, "Libro a borrar.", true, bLibro,
                ConstantesGUI.ELIMINAR, respuesta);
        // Si el usuario presiono el boton Cancelar 
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }
        try {
            // Elimina el libro del catalogo de libros 
            persistencia.eliminar(bLibro);

        } catch (PersistenciaException e) {
            // Si ocurrio un error al borrar del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error. ",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    /**
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del usuario.
     * @return Regresa true si se pudo agregar el usuario, false en caso
     * contrario
     */
    public boolean agregarUsuario(JFrame frame) {
        Usuario usuario = new Usuario();
        StringBuffer respuesta = new StringBuffer("");
        DlgUsuario dlgUsuario;

        String clave = JOptionPane.showInputDialog(frame, "Núm. Credencial.",
                "Agregar Usuario.",
                JOptionPane.QUESTION_MESSAGE);
        // Si el usuario presiono el boton Cancelar 
        if (clave == null) {
            return false;
        }
         //Si no puso una identificacion
        if (clave.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor ingrese una credencial",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Crea un objeto Usuario con solo el num de credencial 
        usuario = new Usuario(clave);

        // Si el usuarios no existe captura los datos del nuevo usuario. 
        // Agrega el nuevo usuario al catalogo de Usuarios. 
        try {
            if (usuario.getNumCredencial() != null) {
                persistencia.agregar(usuario);
            } else {
                return false;
            }
            dlgUsuario = new DlgUsuario(frame, "Captura Datos Usuario.", true,
                    usuario, ConstantesGUI.AGREGAR, respuesta);
            if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR) || usuario.getNombre() == null) {
                persistencia.eliminar(usuario);
                return false;
            }
        } catch (Exception e) {
            // Si ocurrio un error al escribir al catalogo de usuarios, 
            // despliega mensaje de error 
            usuario = persistencia.obten(usuario);
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            dlgUsuario = new DlgUsuario(frame, "Actualizar Usuario.", true,
                    usuario, ConstantesGUI.DESPLEGAR, respuesta);
            if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
                return false;
            }
            return true;
        }
        return true;
    }

    /**
     * Actualiza un Usuario del catalogo de Usuarios.
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * editar los datos del usuario.
     * @return Regresa true si se pudo actualizar el usuario, false en caso
     * contrario
     */
    public boolean actualizarUsuario(JFrame frame) {
        Usuario usuario = new Usuario();
        StringBuffer respuesta = new StringBuffer("");
        DlgUsuario dlgUsuario;
        // Captura el número de credencial del usuario.
        String clave = JOptionPane.showInputDialog(frame, "Núm. Credencial.",
                "Actualizar Usuario",
                JOptionPane.QUESTION_MESSAGE);
        // Si el usuario presiono el boton Cancelar 
        if (clave == null) {
            return false;
        }
        // Crea un objeto Usuario con solo el num de credencial 
        usuario = new Usuario(clave);

        try {
            // Obten el usuario del catalogo de usuarios 
            usuario = persistencia.obten(usuario);
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de usuarios, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Si el usuario no existe, despliega un mensaje de error 
        if (usuario == null) {
            JOptionPane.showMessageDialog(frame,
                    "El Usuario no existe", "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Si el usuario existe, edita los datos del usuario. 
        dlgUsuario = new DlgUsuario(frame, "Edita Datos Usuario.", true, usuario,
                ConstantesGUI.ACTUALIZAR, respuesta);
        // Si el usuario presiono el boton Cancelar 
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }
        // Actualiza el usuario del catalogo de Usuarios. 
        try {
            persistencia.actualizar(usuario);
        } catch (Exception e) {
            // Si ocurrio un error al escribir al catalogo de usuarios, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Elimina un usuario del catalogo de usuarios
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * desplegar los datos del usuario.
     * @return Regresa true si se pudo eliminar el usuario, false en caso
     * contrario
     */
    public boolean eliminarUsuario(JFrame frame) {
        Usuario usuario = new Usuario();
        StringBuffer respuesta = new StringBuffer();
        DlgUsuario dlgUsuarios;
        // Captura la clave del usuario. 
        String clave = JOptionPane.showInputDialog(frame, "Núm. Credencial.",
                "Eliminar Usuario",
                JOptionPane.QUESTION_MESSAGE);
        // Si el usuario presiono el boton Cancelar 
        if (clave == null) {
            return false;
        }
        // Crea un objeto Usuario con solo la clave 
        usuario = new Usuario(clave);

        try {
            // Obten el usuario del catalogo de libros 
            usuario = persistencia.obten(usuario);

        } catch (Exception e) {
            // Si ocurrio un error al leer del catalogo de usuario 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        // Si el usuario no existe en el catalogo de usuarios, 
        if (usuario == null) {
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, "El Usuario no existe.",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Si existe el usuario, despliega los datos del usuario. 
        dlgUsuarios = new DlgUsuario(frame, "Eliminar Usuario.", true, usuario,
                ConstantesGUI.ELIMINAR, respuesta);
        // Si el usuario presiono el boton Cancelar 
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }
        try {
            // Elimina el usuario del catalogo de usuarios 
            persistencia.eliminar(usuario);

        } catch (PersistenciaException e) {
            // Si ocurrio un error al borrar del catalogo de usuarios, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    /**
     * Inventariamos el libro seleccionado.
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del libro.
     * @return Regresa true si se pudo inventariar, false en caso contrario
     */
    public boolean inventariarLibro(JFrame frame) {
        StringBuffer respuesta = new StringBuffer("");
        DlgInventario dlgInventario;
        List<Libro> listaLibros;
        DefaultComboBoxModel<Libro> listaLibrosComboBoxModel;
        try {
            // Obten la lista de libros del catalogo de libros. 
            listaLibros = persistencia.consultarLibros();
            if (listaLibros.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Necesita agregar libros para inventariar!", "Error!!.",
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        listaLibrosComboBoxModel = conversiones.librosComboBoxModel(listaLibros);
        dlgInventario = new DlgInventario(frame,
                "Inventariar Libro.",
                true, listaLibrosComboBoxModel,
                ConstantesGUI.AGREGAR, respuesta, (PersistenciaListas) persistencia);
        return true;

    }

    /**
     * Inventariamos el libro seleccionado.
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del libro.
     * @return Regresa true si se pudo Desinventariar, false en caso contrario
     */
    public boolean desInventariarLibro(JFrame frame) {
        StringBuffer respuesta = new StringBuffer("");
        DlgInventario dlgInventario;
        List<PublicacionED> listaInventario;
        List<Libro> listaLibros;
        DefaultComboBoxModel<Libro> listaLibrosComboBoxModel;
        try {
            // Obten la lista de libros del catalogo de libros. 
            listaInventario = persistencia.consultarInventarioLibros();
            if (listaInventario.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Inventario Vacío!", "Error!!.",
                        JOptionPane.ERROR_MESSAGE);
                return false;
            }
            listaLibros = persistencia.consultarLibros();
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        listaLibrosComboBoxModel = conversiones.librosComboBoxModel(listaLibros);
        dlgInventario = new DlgInventario(frame,
                "Desinventariar Libro.",
                true, listaLibrosComboBoxModel,
                ConstantesGUI.ELIMINAR, respuesta, (PersistenciaListas) persistencia);
        return true;
    }

    /**
     * Prestamos el libro
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del Prestamo.
     * @return Regresa true si se pudo prestar, false en caso contrario.
     */
    public boolean prestarLibro(JFrame frame) {
        StringBuffer respuesta = new StringBuffer("");
        DlgPrestamo dlgPrestamo;
        List<Libro> listaLibros;
        List<Usuario> listaUsuarios;
        DefaultComboBoxModel<Libro> listaLibrosComboBoxModel;
        DefaultComboBoxModel<Usuario> listaUsuariosComboBoxModel;
        List<PublicacionED> listaInventario = persistencia.consultarInventarioLibros();
        try {

            listaLibros = persistencia.consultarLibros();
            listaUsuarios = persistencia.consultarUsuarios();

        } catch (Exception e) {
            // Si ocurrio un error al leer del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        //Verifica que las listas no estén vacias para acceder sin problemas al dlg.
        if (listaLibros.isEmpty() || listaUsuarios.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Aún no existen usuarios o libros para prestar.",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (listaInventario.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El inventarío está vacío, invanteree para continuar!",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        listaLibrosComboBoxModel = conversiones.librosComboBoxModel(listaLibros);
        listaUsuariosComboBoxModel = conversiones.usuariosComboBoxModel(listaUsuarios);
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }
        dlgPrestamo = new DlgPrestamo(frame, true, listaUsuariosComboBoxModel, listaLibrosComboBoxModel,
                ConstantesGUI.AGREGAR, respuesta, "Préstamo", (PersistenciaListas) persistencia);
        return true;

    }

    /**
     * Devolver libro
     *
     * @param frame Ventana sobre la que se despliega el cuadro de dialogo para
     * capturar los datos del Prestamo y poder devolverlo.
     * @return Regresa true si se pudo devolver, false en caso contrario.
     */
    public boolean devolverLibro(JFrame frame) {
        StringBuffer respuesta = new StringBuffer("");
        DlgPrestamo dlgPrestamo;
        List<Libro> listaLibros;
        List<Usuario> listaUsuarios;
        List<Prestamo> listaP;
        DefaultComboBoxModel<Libro> listaLibrosComboBoxModel;
        DefaultComboBoxModel<Usuario> listaUsuariosComboBoxModel;

        try {

            listaLibros = persistencia.consultarLibros();
            listaUsuarios = persistencia.consultarUsuarios();
            listaP = persistencia.consultarPrestamosLibros();
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de libros, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        //Verifica que las listas no estén vacias para acceder sin problemas al dlg.
        if (listaLibros.isEmpty() || listaUsuarios.isEmpty() || listaP.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Aún no existen usuarios, libros o prestamos para devolver.",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        listaLibrosComboBoxModel = conversiones.librosComboBoxModel(listaLibros);
        listaUsuariosComboBoxModel = conversiones.usuariosComboBoxModel(listaUsuarios);
        if (respuesta.substring(0).equals(ConstantesGUI.CANCELAR)) {
            return false;
        }

        dlgPrestamo = new DlgPrestamo(frame, true, listaUsuariosComboBoxModel, listaLibrosComboBoxModel,
                ConstantesGUI.ELIMINAR, respuesta, "Devolver Libro.", (PersistenciaListas) persistencia);
        return true;

    }

    /**
     * Regresa un objeto Tabla con todos los Libros
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los libros, null si hay un error
     */
    public Tabla getTablaLibros(JFrame frame) {
        List<Libro> listaLibros;
        try {
            // Obtiene la lista de Libros 
            listaLibros = persistencia.consultarLibros();

        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los libros. 
        return new Tabla("Lista de Libros",
                conversiones.librosTableModel(listaLibros));

    }

    /**
     * Regresa un objeto Tabla con todos los libros del mismo autor.
     *
     * @param frame Ventana sobre la que se despliega el mensaje.
     * @return Objeto Tabla con todos los libros, null si hay un error
     */
    public Tabla getTablaLibrosAutor(JFrame frame) {
        List<Libro> listaLibros;
        String autor = JOptionPane.showInputDialog(frame, "Ingrese el Autor.",
                "Lista de Libros del mismo Autor.",
                JOptionPane.QUESTION_MESSAGE);
        if (autor == null) {
            return null;
        }
        try {
            // Obtiene la lista de Libros 
            listaLibros = persistencia.consultarLibrosAutor(autor);
            if (listaLibros.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "El Autor no existe en esta lista!.",
                        "Error!!.", JOptionPane.ERROR_MESSAGE);
                return null;
            }

        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(frame, "Ocurrió un error inesperado. Lo siento :c",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        // Regresa el objeto Tabla con todos los libros. 
        return new Tabla("Lista de Libros del Autor: " + autor.toUpperCase(),
                conversiones.librosTableModel(listaLibros));

    }

    /**
     * Regresa un objeto Tabla con todos los libros de la misma editorial.
     *
     * @param frame Ventana sobre la que se despliega el mensaje.
     * @return Objeto Tabla con todos los libros, null si hay un error
     */
    public Tabla getTablaLibrosEditorial(JFrame frame) {
        List<Libro> listaLibros;
        String editorial = JOptionPane.showInputDialog(frame, "Ingrese la Editorial.",
                "Lista de Libros de la misma Editorial.",
                JOptionPane.QUESTION_MESSAGE);
        if (editorial == null) {
            return null;
        }
        try {

            // Obtiene la lista de Libros con la misma editorial.
            listaLibros = persistencia.consultarLibrosEditorial(editorial);

            if (listaLibros.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "La editorial no existe en esta lista!.",
                        "Error!!.", JOptionPane.ERROR_MESSAGE);
                return null;
            }

        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(frame, "Ocurrió un error inesperado. Lo siento :c",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los libros. 
        return new Tabla("Lista de Libros de la Editorial: " + editorial.toUpperCase(),
                conversiones.librosTableModel(listaLibros));
    }

    /**
     * Regresa un objeto Tabla con todos los libros de la misma clasificacion.
     *
     * @param frame Ventana sobre la que se despliega el mensaje.
     * @return Objeto Tabla con todos los libros, null si hay un error
     */
    public Tabla getTablaLibrosClasificacion(JFrame frame) {
        List<Libro> listaLibros;
        String clasificacion = JOptionPane.showInputDialog(frame, "Ingrese la Clasificación.",
                "Lista de Libros de la misma Clasificación.",
                JOptionPane.QUESTION_MESSAGE);
        if (clasificacion == null) {
            return null;
        }
        try {

            // Obtiene la lista de Libros 
            listaLibros = persistencia.consultarLibrosClasificacion(clasificacion);
            if (listaLibros.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "La Clasificación no existe en esta lista!.",
                        "Error!!.", JOptionPane.ERROR_MESSAGE);
                return null;
            }

        } catch (PersistenciaException e) {
            JOptionPane.showMessageDialog(frame, "Ocurrió un error inesperado. Lo siento :c",
                    "Error!!.", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los libros. 
        return new Tabla("Lista de Libros de la Clasificación: " + clasificacion.toUpperCase(),
                conversiones.librosTableModel(listaLibros));
    }

    /**
     * Regresa un objeto Tabla con todos los Usuarios
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los usuarios, null si hay un error
     */
    public Tabla getTablaUsuarios(JFrame frame) {
        List<Usuario> listaUsuarios;
        try {
            // Obtiene la lista de Usuarios 
            listaUsuarios = persistencia.consultarUsuarios();

        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los Usuarios 
        return new Tabla("Lista de los Usuarios",
                conversiones.usuariosTableModel(listaUsuarios));
    }

    /**
     * Regresa un objeto Tabla con todo el inventario
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos el inventario, null si hay un error
     */
    public Tabla getTablaInventarios(JFrame frame) {
        List<PublicacionED> listaInventario;
        try {
            // Obtiene la lista de inventario 
            listaInventario = persistencia.consultarInventarioLibros();

        } catch (PersistenciaException e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        // Regresa el objeto Tabla con todo el inventario. 
        return new Tabla("Lista del Inventario",
                conversiones.inventarioLibrosTableModel(listaInventario));
    }

    /**
     * Regresa un objeto Tabla con todos los prestamos
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los prestamos, null si hay un error
     */
    public Tabla getTablaPrestamosLibroISBN(JFrame frame) {
        List<Prestamo> listaPrestamos;
        Libro libro;
        String isbn = JOptionPane.showInputDialog(frame, "Ingrese el ISBN.",
                "Lista de Prestamos del mismo Libro.",
                JOptionPane.QUESTION_MESSAGE);
        if (isbn == null) {
            return null;
        }
        libro = new Libro(isbn);
        try {
            // Obtiene la lista de prestamos. 

            listaPrestamos = persistencia.consultarPrestamos(libro);
            if (listaPrestamos.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No se encontraron libros prestados del usuario especificado o el libro no existe.", "Error!!.",
                        JOptionPane.ERROR_MESSAGE);
                return null;
            }

        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos.
        return new Tabla("Lista de Prestamos del mismo Libro: " + isbn,
                conversiones.prestamoLibrosTableModel(listaPrestamos));
    }

    /**
     * Regresa un objeto Tabla con todos los prestamos del mismo Libro
     *
     * @param frame Ventana del menú de error
     * @return Objeto Tabla con todos los prestamos, null si hay error.
     */
    public Tabla getTablaPrestamosLibro(JFrame frame) {
        List<Prestamo> listaPrestamos;

        try {
            // Obtiene la lista de prestamos. 

            listaPrestamos = persistencia.consultarPrestamosLibros();

        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos.
        return new Tabla("Lista de Prestamos",
                conversiones.prestamoLibrosTableModel(listaPrestamos));
    }

    /**
     * Regresa un objeto Tabla con todos los prestamos
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los prestamos, null si hay un error
     */
    public Tabla getTablaPrestamosLibroPeriodo(JFrame frame) {
        Periodo periodo = new Periodo();
        DlgPeriodo dlgPeriodo;
        List<Prestamo> listaPrestamos;
        StringBuffer respuesta = new StringBuffer("");
        if (persistencia.consultarPrestamosLibros().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Aún no hay prestamos que consultar.", "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        dlgPeriodo = new DlgPeriodo(frame, "Consultar Prestamos en cierto periodo", true,
                ConstantesGUI.AGREGAR, respuesta, periodo);
        if (periodo.getDesde() == null || periodo.getHasta() == null) {
            return null;
        }
        try {
            // Obtiene la lista de prestamos del mismo periodo.
            listaPrestamos = persistencia.consultarPrestamosLibros(periodo);
            if (listaPrestamos.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No se encontraron prestamos del mismo periodo.", "Error!!.",
                        JOptionPane.ERROR_MESSAGE);
                return null;
            }
        } catch (PersistenciaException e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos del mismo periodo.
        return new Tabla("Lista de Prestamos del Periodo: " + periodo.toString(),
                conversiones.prestamoLibrosTableModel(listaPrestamos));
    }

    /**
     * Regresa un objeto Tabla con todos los libros prestados.
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los prestamos, null si hay un error
     */
    public Tabla getTablaLibrosPrestados(JFrame frame) {
        List<PublicacionED> librosPrestados;
        try {
            // Obtiene la lista de libros prestados. 
            librosPrestados = persistencia.consultarLibrosPrestados();
            if (librosPrestados.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No hay libros prestados hasta el momento!",
                        "Error!!.", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos.
        return new Tabla("Lista de Libros Prestados",
                conversiones.inventarioLibrosTableModel(librosPrestados));
    }

    /**
     * Regresa un objeto Tabla con todos los libros disponibles.
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los prestamos, null si hay un error
     */
    public Tabla getTablaLibrosDisponibles(JFrame frame) {
        List<PublicacionED> librosDisponibles;
        try {
            // Obtiene la lista de libros disponibles. 
            librosDisponibles = persistencia.consultarLibrosDisponibles();
            if (librosDisponibles.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No hay libros disponibles hasta el momento!",
                        "Error!!.", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos.
        return new Tabla("Lista de Libros Disponibles",
                conversiones.inventarioLibrosTableModel(librosDisponibles));
    }

    /**
     * Regresa un objeto Tabla con todos los libros disponibles.
     *
     * @param frame Ventana sobre la que se despliega el mensaje de error
     * @return Objeto Tabla con todos los prestamos, null si hay un error
     */
    public Tabla getTablaPrestamosLibrosUsuario(JFrame frame) {
        List<Prestamo> librosPrestamosLibrosUsuario;
        Usuario usuario = new Usuario();
        // Captura el número de credencial del usuario.
        String clave = JOptionPane.showInputDialog(frame, "Núm. Credencial.",
                "Prestamos del mismo Usuario",
                JOptionPane.QUESTION_MESSAGE);
        // Si el usuario presiono el boton Cancelar 
        if (clave == null) {
            return null;
        }
        // Crea un objeto Usuario con solo el num de credencial 
        usuario = new Usuario(clave);

        try {
            // Obten el usuario del catalogo de usuarios 
            usuario = persistencia.obten(usuario);
        } catch (PersistenciaException e) {
            // Si ocurrio un error al leer del catalogo de usuarios, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Si el usuario no existe, despliega un mensaje de error 
        if (usuario == null) {
            JOptionPane.showMessageDialog(frame,
                    "Usuario inexistente", "Error.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        try {
            // Obtiene la lista de libros disponibles. 
            librosPrestamosLibrosUsuario = persistencia.consultarPrestamosLibros(usuario);
            if (librosPrestamosLibrosUsuario.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Éste usuario aún no tiene préstamos!", "Error.",
                        JOptionPane.ERROR_MESSAGE);
                return null;
            }
        } catch (Exception e) {
            // Si ocurrio un error al obtener la lista de la base de datos, 
            // despliega mensaje de error 
            JOptionPane.showMessageDialog(frame, e.getMessage(), "Error!!.",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }
        // Regresa el objeto Tabla con todos los prestamos.
        return new Tabla("Lista de Libros prestados a: " + usuario.getNombre().toUpperCase(),
                conversiones.prestamoLibrosTableModel(librosPrestamosLibrosUsuario));
    }

}


