package control;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import objetosNegocio.*;
import objetosServicio.Fecha;
/**
 * Clase Control
 * @author Asiel Apodaca Monge 00000247722
 */
public class Conversiones {
    // Arreglos con los nombres de las columnas de las tablas 
    String nombresColumnasTablasLibros[] = {
        "ISBN","Titulo","Autor","Edición","Clasificación","Editorial"
    };
    String nombresColumnasTablasUsuarios[] = {
        "Credencial","Nombre","Direccion","Telefono"
    };
    String nombresColumnasTablasInventarios[] = {
        "Libro","Existencia","Disponibilidad"
    };
    String nombresColumnasTablasPrestamos[] = {
        "Libro","Usuario","Desde","Hasta"
    };
    
    /**
     * Genera un objeto de tipo DefaultTableModel a partir de una lista de
     * libros.
     *
     * @param listaLibros Lista de Libros a convertir
     * @return Objeto de tipo DefaultTableModel con los atributos de Libro.
     */
    public DefaultTableModel librosTableModel(List<Libro> listaLibros) {
        Object tabla[][];
        if (listaLibros != null) {
            tabla = new Object[listaLibros.size()][6];
            for (int i = 0; i < listaLibros.size(); i++) {

                // Obten un libro de la lista de libros 
                Libro libro = listaLibros.get(i);
                // Almacena sus atributos en la fila del arreglo 
                tabla[i][0] = libro.getIsbn();
                tabla[i][1] = libro.getTitulo();
                tabla[i][2] = libro.getAutor();
                tabla[i][3] = libro.getEdicion();
                tabla[i][4] = libro.getClasificacion();
                tabla[i][5] = libro.getEditorial();
            }
            return new DefaultTableModel(tabla, nombresColumnasTablasLibros);
        }
        return null;
    }

    /**
     * Genera un objeto de tipo DefaultTableModel a partir de una lista de
     * usuarios.
     *
     * @param listaUsuarios Lista de usuarios a convertir
     * @return Objeto de tipo DefaultTableModel con los atributos de los
     * Usuario.
     */
    public DefaultTableModel usuariosTableModel(List<Usuario> listaUsuarios) {
        Object tabla[][];
        if (listaUsuarios != null) {
            tabla = new Object[listaUsuarios.size()][4];
            for (int i = 0; i < listaUsuarios.size(); i++) {
                // Obten una canción de la lista de usuarios 
                Usuario usuario = listaUsuarios.get(i);
                // Almacena sus atributos en la fila del arreglo 
                tabla[i][0] = usuario.getNumCredencial();
                tabla[i][1] = usuario.getNombre();
                tabla[i][2] = usuario.getDireccion();
                tabla[i][3] = usuario.getTelefono();
            }
            return new DefaultTableModel(tabla, nombresColumnasTablasUsuarios);
        }
        return null;
    }

    /**
     * Genera un objeto de tipo DefaultTableModel a partir de una lista de
     * inventarios
     *
     * @param listaInventarioLibros Lista de inventario de los libros
     * @return Objeto de tipo DefaultTableModel con los atributos de
     * PublicacionED
     */
    public DefaultTableModel inventarioLibrosTableModel(List<PublicacionED> listaInventarioLibros) {
        Object tabla[][];
        if (listaInventarioLibros != null) {
            tabla = new Object[listaInventarioLibros.size()][3];
            for (int i = 0; i < listaInventarioLibros.size(); i++) {
                // Obten un inventario de la lista de inventarios 
                PublicacionED publicacionED = listaInventarioLibros.get(i);
                // Almacena sus atributos en la fila del arreglo 
                tabla[i][0] = publicacionED.getPublicacion().getIsbn();
                tabla[i][1] = publicacionED.getExistencia();
                tabla[i][2] = publicacionED.getDisponibilidad();
            }
            return new DefaultTableModel(tabla, nombresColumnasTablasInventarios);
        }
        return null;
    }

    /**
     * Genera un objeto de tipo DefaultTableModel a partir de una lista de
     * prestamos.
     *
     * @param listaPrestamoLibros Lista de los prestamos
     * @return Objeto de tipo DefaultTableModel con los atributos de los
     * prestamos.
     */
    public DefaultTableModel prestamoLibrosTableModel(List<Prestamo> listaPrestamoLibros) {
        Object tabla[][];
        if (listaPrestamoLibros != null) {
            tabla = new Object[listaPrestamoLibros.size()][5];
            for (int i = 0; i < listaPrestamoLibros.size(); i++) {
                // Obten un género de la lista de prestamos 
                Prestamo prestamo = (Prestamo) listaPrestamoLibros.get(i);
                // Almacena sus atributos en la fila del arreglo 
                tabla[i][0] = prestamo.getPublicacion().getIsbn();
                tabla[i][1] = prestamo.getUsuario().getNombre();
                tabla[i][2] = prestamo.getFechaPrestamo().toString();
                tabla[i][3] = new Fecha().vencimiento(prestamo.getTiempoPrestamo());
            }
            return new DefaultTableModel(tabla, nombresColumnasTablasPrestamos);
        }
        return null;
    }

    /**
     * Genera un objeto de tipo DefaultComboBoxModel a partir de una lista de
     * libros.
     *
     * @param listaLibros Lista de los libros.
     * @return Lista de libros en una combo box model.
     */
    public DefaultComboBoxModel<Libro> librosComboBoxModel(List<Libro> listaLibros) {
        DefaultComboBoxModel<Libro> defaultComboBoxModel = new DefaultComboBoxModel<>();
        if (listaLibros != null) {
            // Para cada elemento de la Lista 
            for (int i = 0; i < listaLibros.size(); i++) {
                // Agregalo a la instancia de la clase DefaultComboBoxModel 
                defaultComboBoxModel.addElement(listaLibros.get(i));
            }
            return defaultComboBoxModel;
        }
        return null;
    }

    /**
     * Genera un objeto de tipo DefaultComboBoxModel a partir de una lista de
     * usuarios
     *
     * @param listaUsuarios Lista de los usuarios.
     * @return Lista de los usuarios en una combo box model.
     */
    public DefaultComboBoxModel<Usuario> usuariosComboBoxModel(List<Usuario> listaUsuarios) {
        DefaultComboBoxModel<Usuario> defaultComboBoxModel = new DefaultComboBoxModel<>();
        if (listaUsuarios != null) {
            // Para cada elemento de la Lista 
            for (int i = 0; i < listaUsuarios.size(); i++) {
                // Agregalo a la instancia de la clase DefaultComboBoxModel 
                defaultComboBoxModel.addElement(listaUsuarios.get(i));
            }
            return defaultComboBoxModel;
        }
        return null;
    }

}
